# Build VKFLAME Launcher APK using only an Android phone

This project includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.

1. Create a GitHub account and a new repository named `VKFLAME_LAUNCHER`.
2. Upload the contents of this project folder to the repository root (not the outer folder itself).
3. Open the repository's Actions tab and enable workflows if GitHub asks.
4. Open `Build VKFLAME Launcher APK` and tap `Run workflow` (or push to `main`).
5. Wait for the run to finish successfully. Open the completed run and download the artifact named `VKFLAME-LAUNCHER-debug-apk`.
6. Extract the artifact ZIP on the phone and install `app-debug.apk`. If Android asks, allow installation from the browser/files app you used.

This builds the Android app source. It does not add missing Minecraft Java/Bedrock runtime components or guarantee that the Play button can launch a game. Those need separate implementation and testing.
