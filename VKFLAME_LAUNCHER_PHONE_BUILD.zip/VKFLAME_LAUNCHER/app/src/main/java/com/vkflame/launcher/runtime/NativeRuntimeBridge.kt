package com.vkflame.launcher.runtime

import android.content.Context
import android.content.pm.PackageManager
import com.vkflame.launcher.model.GameProfile
import com.vkflame.launcher.model.MinecraftEdition
import java.io.File

data class LaunchChecklist(
    val readyForNativeExecution: Boolean,
    val summary: String,
    val jvmCommandPreview: List<String>,
    val missingNativeModules: List<String>
)

/**
 * Separates working Kotlin/Compose launcher configuration & argument generation
 * from native Android runtime binaries (OpenJDK ARM64, LWJGL3, GL4ES/Zink, or Bedrock APK hook)
 * that must be compiled and bundled separately into jniLibs/.
 */
class NativeRuntimeBridge(private val context: Context) {

    fun inspectReadiness(profile: GameProfile): LaunchChecklist {
        val missing = mutableListOf<String>()

        if (profile.edition == MinecraftEdition.JAVA) {
            val jreDir = File(context.filesDir, "runtimes/openjdk")
            val nativeLibDir = File(context.applicationInfo.nativeLibraryDir)
            val hasLwjgl = File(nativeLibDir, "liblwjgl.so").exists()
            val hasRenderer = File(nativeLibDir, "libgl4es_114.so").exists()

            if (!jreDir.exists()) missing += "ARM64 OpenJDK runtime not extracted in filesDir/runtimes/openjdk"
            if (!hasLwjgl) missing += "Native JNI bridge liblwjgl.so missing from jniLibs/arm64-v8a"
            if (!hasRenderer) missing += "Graphics wrapper (${profile.renderer.name}) native .so not bundled"
            missing += "Mojang Piston client.jar + Microsoft Xbox Live OAuth token flow"
        } else {
            val bedrockInstalled = isPackageInstalled("com.mojang.minecraftpe")
            if (!bedrockInstalled) {
                missing += "Minecraft Bedrock APK (com.mojang.minecraftpe) not installed on device"
            }
            missing += "Native Bedrock launcher hook / libminecraftpe.so bridge not attached"
        }

        val jvmArgs = buildJavaCommandLine(profile)
        return LaunchChecklist(
            readyForNativeExecution = missing.isEmpty(),
            summary = if (missing.isEmpty()) {
                "All native runtime dependencies satisfied."
            } else {
                "Profile validated; ${missing.size} native runtime component(s) required before boot."
            },
            jvmCommandPreview = jvmArgs,
            missingNativeModules = missing
        )
    }

    fun buildJavaCommandLine(profile: GameProfile): List<String> {
        if (profile.edition == MinecraftEdition.BEDROCK) {
            return listOf("am", "start", "-n", "com.mojang.minecraftpe/.MainActivity")
        }
        val args = mutableListOf(
            "java",
            "-Xms${(profile.ramMb / 2).coerceAtLeast(512)}M",
            "-Xmx${profile.ramMb}M",
            "-Dorg.lwjgl.opengl.libname=${profile.renderer.name.lowercase()}",
            "-Dvkflame.resolution=${profile.resolution.width}x${profile.resolution.height}",
            "-Dvkflame.scale=${profile.resolution.scalePercent}"
        )
        if (profile.jvmArgs.isNotBlank()) {
            args += profile.jvmArgs.split(" ").filter { it.isNotBlank() }
        }
        args += listOf(
            "-Dminecraft.version=${profile.mcVersion}",
            "-Dvkflame.loader=${profile.loader.name.lowercase()}:${profile.loaderVersion}",
            "net.minecraft.client.main.Main"
        )
        return args
    }

    private fun isPackageInstalled(packageName: String): Boolean = try {
        context.packageManager.getPackageInfo(packageName, 0)
        true
    } catch (_: PackageManager.NameNotFoundException) {
        false
    }
}
