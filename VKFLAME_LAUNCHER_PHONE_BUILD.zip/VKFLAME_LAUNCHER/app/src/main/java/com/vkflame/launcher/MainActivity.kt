package com.vkflame.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.vkflame.launcher.data.ProfileRepository
import com.vkflame.launcher.model.*
import com.vkflame.launcher.runtime.NativeRuntimeBridge
import com.vkflame.launcher.ui.*
import com.vkflame.launcher.ui.theme.*

enum class LauncherDestination(val label: String) {
    HOME("Home"),
    MODS("Mods"),
    CONTROLS("Controls"),
    SETTINGS("Settings")
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val repository = ProfileRepository(applicationContext)
        val runtimeBridge = NativeRuntimeBridge(applicationContext)

        setContent {
            VkFlameLauncherTheme {
                var destination by remember { mutableStateOf(LauncherDestination.HOME) }
                var profiles by remember { mutableStateOf(repository.loadSeedOrSavedProfiles()) }
                var activeIndex by remember { mutableIntStateOf(0) }
                var controlLayout by remember { mutableStateOf(repository.loadControlLayout()) }

                val activeProfile = profiles[activeIndex]
                val scannedMods = remember(activeProfile) {
                    repository.scanModsDirectory(activeProfile.gameDir, activeProfile.edition)
                }

                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(VkBlackCanvas)
                        .systemBarsPadding()
                ) {
                    NavigationRail(
                        containerColor = VkSurface,
                        modifier = Modifier.width(84.dp)
                    ) {
                        LauncherDestination.entries.forEach { dest ->
                            val icon = when (dest) {
                                LauncherDestination.HOME -> Icons.Rounded.Home
                                LauncherDestination.MODS -> Icons.Rounded.Extension
                                LauncherDestination.CONTROLS -> Icons.Rounded.Gamepad
                                LauncherDestination.SETTINGS -> Icons.Rounded.Tune
                            }
                            NavigationRailItem(
                                selected = destination == dest,
                                onClick = { destination = dest },
                                icon = { Icon(icon, contentDescription = dest.label) },
                                label = { Text(dest.label) }
                            )
                        }
                    }

                    Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                        when (destination) {
                            LauncherDestination.HOME -> HomeScreen(
                                activeProfile = activeProfile,
                                profiles = profiles,
                                onSelectEdition = { edition ->
                                    val updated = activeProfile.copy(edition = edition)
                                    profiles = profiles.toMutableList().also { it[activeIndex] = updated }
                                    repository.saveProfiles(profiles)
                                },
                                onSelectProfile = { selected ->
                                    val idx = profiles.indexOfFirst { it.id == selected.id }
                                    if (idx >= 0) activeIndex = idx
                                },
                                onSelectLoader = { loader ->
                                    val updated = activeProfile.copy(loader = loader)
                                    profiles = profiles.toMutableList().also { it[activeIndex] = updated }
                                    repository.saveProfiles(profiles)
                                },
                                onRequestLaunch = { runtimeBridge.inspectReadiness(activeProfile) }
                            )

                            LauncherDestination.MODS -> ModsScreen(
                                mods = scannedMods,
                                onToggleMod = { mod ->
                                    repository.toggleModFile(activeProfile.gameDir, mod.fileName, !mod.enabled)
                                }
                            )

                            LauncherDestination.CONTROLS -> ControlEditorScreen(
                                layout = controlLayout,
                                onSaveLayout = { updated ->
                                    controlLayout = updated
                                    repository.saveControlLayout(updated)
                                }
                            )

                            LauncherDestination.SETTINGS -> SettingsScreen(
                                profile = activeProfile,
                                onUpdateProfile = { updated ->
                                    profiles = profiles.toMutableList().also { it[activeIndex] = updated }
                                    repository.saveProfiles(profiles)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
