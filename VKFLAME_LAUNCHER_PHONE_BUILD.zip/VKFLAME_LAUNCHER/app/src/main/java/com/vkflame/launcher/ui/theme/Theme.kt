package com.vkflame.launcher.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val VkBlackCanvas = Color(0xFF06080D)
val VkSurface = Color(0xFF0C1018)
val VkSurfaceElevated = Color(0xFF131A29)
val VkBorder = Color(0xFF1C263D)
val VkBluePrimary = Color(0xFF2563EB)
val VkBlueBright = Color(0xFF3B82F6)
val VkTextPrimary = Color(0xFFF1F5F9)
val VkTextMuted = Color(0xFF94A3B8)

private val VkFlameColorScheme = darkColorScheme(
    primary = VkBluePrimary,
    onPrimary = Color.White,
    secondary = VkBlueBright,
    background = VkBlackCanvas,
    onBackground = VkTextPrimary,
    surface = VkSurface,
    onSurface = VkTextPrimary,
    surfaceVariant = VkSurfaceElevated,
    onSurfaceVariant = VkTextMuted,
    outline = VkBorder
)

@Composable
fun VkFlameLauncherTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = VkFlameColorScheme,
        content = content
    )
}
