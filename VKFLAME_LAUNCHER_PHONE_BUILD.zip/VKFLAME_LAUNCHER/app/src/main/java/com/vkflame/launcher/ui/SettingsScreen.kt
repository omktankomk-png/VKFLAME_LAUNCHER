package com.vkflame.launcher.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vkflame.launcher.model.GameProfile
import com.vkflame.launcher.ui.theme.*
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(
    profile: GameProfile,
    onUpdateProfile: (GameProfile) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Text(
            text = "Memory & Resolution Settings",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = VkTextPrimary
        )

        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = "RAM Allocation: ${profile.ramMb} MB",
                color = VkTextPrimary,
                fontSize = 14.sp
            )
            Slider(
                value = profile.ramMb.toFloat(),
                onValueChange = { mb ->
                    val snapped = ((mb / 256f).roundToInt() * 256).coerceIn(512, 8192)
                    onUpdateProfile(profile.copy(ramMb = snapped))
                },
                valueRange = 512f..8192f
            )
        }

        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = "Resolution Scale: ${profile.resolution.scalePercent}% (${profile.resolution.width}x${profile.resolution.height})",
                color = VkTextPrimary,
                fontSize = 14.sp
            )
            Slider(
                value = profile.resolution.scalePercent.toFloat(),
                onValueChange = { pct ->
                    onUpdateProfile(
                        profile.copy(
                            resolution = profile.resolution.copy(scalePercent = pct.roundToInt())
                        )
                    )
                },
                valueRange = 50f..100f
            )
        }
    }
}
