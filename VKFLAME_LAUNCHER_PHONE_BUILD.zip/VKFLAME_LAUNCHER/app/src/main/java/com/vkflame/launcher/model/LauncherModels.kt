package com.vkflame.launcher.model

import kotlinx.serialization.Serializable

@Serializable
enum class MinecraftEdition { JAVA, BEDROCK }

@Serializable
enum class ModLoader { VANILLA, FABRIC, FORGE, NEOFORGE }

@Serializable
enum class GraphicsRenderer { GL4ES, ZINK, VIRGL, ANGLE }

@Serializable
enum class ControlShape { CIRCLE, ROUNDED, SQUARE }

@Serializable
data class ResolutionConfig(
    val width: Int = 1280,
    val height: Int = 720,
    val scalePercent: Int = 85,
    val fullscreen: Boolean = true,
    val ignoreNotch: Boolean = true
)

@Serializable
data class GameProfile(
    val id: String,
    val name: String,
    val edition: MinecraftEdition,
    val mcVersion: String,
    val loader: ModLoader,
    val loaderVersion: String,
    val ramMb: Int,
    val jvmArgs: String,
    val renderer: GraphicsRenderer,
    val resolution: ResolutionConfig,
    val controlLayoutId: String,
    val gameDir: String
)

@Serializable
data class ModEntry(
    val id: String,
    val name: String,
    val fileName: String,
    val edition: MinecraftEdition,
    val loader: String,
    val mcVersion: String,
    val enabled: Boolean
)

@Serializable
data class TouchControlButton(
    val id: String,
    val label: String,
    val keycode: String,
    val xPercent: Float,
    val yPercent: Float,
    val widthDp: Int,
    val heightDp: Int,
    val opacity: Float,
    val shape: ControlShape = ControlShape.ROUNDED,
    val toggleable: Boolean = false
)

@Serializable
data class TouchControlLayout(
    val id: String,
    val name: String,
    val buttons: List<TouchControlButton>
)
