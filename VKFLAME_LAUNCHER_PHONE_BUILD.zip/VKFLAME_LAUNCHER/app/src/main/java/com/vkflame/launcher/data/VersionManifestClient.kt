package com.vkflame.launcher.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.net.HttpURLConnection
import java.net.URL

@Serializable
data class MojangVersionEntry(
    val id: String,
    val type: String,
    val url: String,
    val releaseTime: String
)

@Serializable
data class MojangManifestResponse(
    val versions: List<MojangVersionEntry>
)

class VersionManifestClient {

    private val json = Json { ignoreUnknownKeys = true }

    suspend fun fetchJavaVersions(): Result<List<MojangVersionEntry>> = withContext(Dispatchers.IO) {
        runCatching {
            val url = URL("https://piston-meta.mojang.com/mc/game/version_manifest_v2.json")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 8000
            }
            conn.inputStream.bufferedReader().use { reader ->
                val parsed = json.decodeFromString<MojangManifestResponse>(reader.readText())
                parsed.versions.filter { it.type == "release" }.take(25)
            }
        }
    }
}
