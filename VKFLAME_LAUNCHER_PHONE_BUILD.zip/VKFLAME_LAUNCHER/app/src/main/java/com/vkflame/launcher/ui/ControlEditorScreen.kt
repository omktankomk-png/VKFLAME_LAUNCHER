package com.vkflame.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vkflame.launcher.model.ControlShape
import com.vkflame.launcher.model.TouchControlLayout
import com.vkflame.launcher.ui.theme.*
import kotlin.math.roundToInt

@Composable
fun ControlEditorScreen(
    layout: TouchControlLayout,
    onSaveLayout: (TouchControlLayout) -> Unit
) {
    var workingLayout by remember(layout) { mutableStateOf(layout) }
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "MJ Touch Control Editor — ${workingLayout.name}",
                color = VkTextPrimary,
                fontWeight = FontWeight.SemiBold,
                fontSize = 16.sp
            )
            Button(
                onClick = { onSaveLayout(workingLayout) },
                colors = ButtonDefaults.buttonColors(containerColor = VkBluePrimary)
            ) {
                Text("Save Layout")
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0xFF04060A))
                .border(1.dp, VkBorder, RoundedCornerShape(14.dp))
                .onSizeChanged { canvasSize = it }
        ) {
            workingLayout.buttons.forEach { btn ->
                val shape = when (btn.shape) {
                    ControlShape.CIRCLE -> CircleShape
                    ControlShape.ROUNDED -> RoundedCornerShape(10.dp)
                    ControlShape.SQUARE -> RoundedCornerShape(2.dp)
                }

                val pxX = ((btn.xPercent / 100f) * canvasSize.width).roundToInt()
                val pxY = ((btn.yPercent / 100f) * canvasSize.height).roundToInt()

                Box(
                    modifier = Modifier
                        .offset { IntOffset(pxX, pxY) }
                        .size(btn.widthDp.dp, btn.heightDp.dp)
                        .alpha(btn.opacity)
                        .clip(shape)
                        .background(VkSurfaceElevated)
                        .border(1.5.dp, VkBlueBright, shape)
                        .pointerInput(btn.id, canvasSize) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                if (canvasSize.width > 0 && canvasSize.height > 0) {
                                    val dxPct = (dragAmount.x / canvasSize.width) * 100f
                                    val dyPct = (dragAmount.y / canvasSize.height) * 100f
                                    workingLayout = workingLayout.copy(
                                        buttons = workingLayout.buttons.map { item ->
                                            if (item.id == btn.id) {
                                                item.copy(
                                                    xPercent = (item.xPercent + dxPct).coerceIn(0f, 92f),
                                                    yPercent = (item.yPercent + dyPct).coerceIn(0f, 88f)
                                                )
                                            } else item
                                        }
                                    )
                                }
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = btn.label,
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
