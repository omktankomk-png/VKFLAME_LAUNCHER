package com.vkflame.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vkflame.launcher.model.ModEntry
import com.vkflame.launcher.ui.theme.*

@Composable
fun ModsScreen(
    mods: List<ModEntry>,
    onToggleMod: (ModEntry) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "Mods & Resource Packs (${mods.size})",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = VkTextPrimary
        )

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(mods, key = { it.id }) { mod ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(VkSurface)
                        .border(1.dp, VkBorder, RoundedCornerShape(12.dp))
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(mod.name, color = VkTextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Text("${mod.loader} · ${mod.mcVersion} · ${mod.fileName}", color = VkTextMuted, fontSize = 12.sp)
                    }
                    Switch(
                        checked = mod.enabled,
                        onCheckedChange = { onToggleMod(mod) }
                    )
                }
            }
        }
    }
}
