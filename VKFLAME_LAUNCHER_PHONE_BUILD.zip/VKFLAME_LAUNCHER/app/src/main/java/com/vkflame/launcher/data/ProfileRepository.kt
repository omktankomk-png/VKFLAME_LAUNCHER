package com.vkflame.launcher.data

import android.content.Context
import com.vkflame.launcher.model.*
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

class ProfileRepository(private val context: Context) {

    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
    }

    private val configDir: File
        get() = File(context.filesDir, "vkflame").apply { mkdirs() }

    private val profilesFile: File
        get() = File(configDir, "profiles.json")

    private val controlsFile: File
        get() = File(configDir, "controls.json")

    fun loadSeedOrSavedProfiles(): List<GameProfile> {
        if (profilesFile.exists()) {
            return runCatching {
                json.decodeFromString<List<GameProfile>>(profilesFile.readText())
            }.getOrElse { defaultProfiles() }
        }
        return defaultProfiles().also { saveProfiles(it) }
    }

    fun saveProfiles(profiles: List<GameProfile>) {
        profilesFile.writeText(json.encodeToString(profiles))
    }

    fun scanModsDirectory(gameDirPath: String, edition: MinecraftEdition): List<ModEntry> {
        val folder = File(gameDirPath, if (edition == MinecraftEdition.JAVA) "mods" else "resource_packs")
        if (!folder.exists()) return emptyList()

        return folder.listFiles()
            ?.filter { file ->
                val ext = file.extension.lowercase()
                ext == "jar" || ext == "disabled" || ext == "mcpack" || ext == "mcaddon"
            }
            ?.map { file ->
                ModEntry(
                    id = file.name,
                    name = file.nameWithoutExtension.removeSuffix(".jar"),
                    fileName = file.name,
                    edition = edition,
                    loader = if (edition == MinecraftEdition.JAVA) "java-mod" else "bedrock-pack",
                    mcVersion = "Detected",
                    enabled = !file.name.endsWith(".disabled")
                )
            }
            ?: emptyList()
    }

    fun toggleModFile(gameDirPath: String, fileName: String, enable: Boolean): Boolean {
        val modsDir = File(gameDirPath, "mods")
        val target = File(modsDir, fileName)
        if (!target.exists()) return false
        val newName = if (enable) {
            fileName.removeSuffix(".disabled")
        } else {
            if (fileName.endsWith(".disabled")) fileName else "$fileName.disabled"
        }
        return target.renameTo(File(modsDir, newName))
    }

    fun loadControlLayout(): TouchControlLayout {
        if (controlsFile.exists()) {
            return runCatching {
                json.decodeFromString<TouchControlLayout>(controlsFile.readText())
            }.getOrElse { defaultControlLayout() }
        }
        return defaultControlLayout().also { saveControlLayout(it) }
    }

    fun saveControlLayout(layout: TouchControlLayout) {
        controlsFile.writeText(json.encodeToString(layout))
    }

    private fun defaultProfiles(): List<GameProfile> = listOf(
        GameProfile(
            id = "profile-java-fabric",
            name = "VKFLAME Performance 1.21.4",
            edition = MinecraftEdition.JAVA,
            mcVersion = "1.21.4",
            loader = ModLoader.FABRIC,
            loaderVersion = "0.16.9",
            ramMb = 4096,
            jvmArgs = "-XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=120",
            renderer = GraphicsRenderer.GL4ES,
            resolution = ResolutionConfig(
                width = 1280,
                height = 720,
                scalePercent = 85,
                fullscreen = true,
                ignoreNotch = true
            ),
            controlLayoutId = "mj-claw-default",
            gameDir = "/storage/emulated/0/VKFlame/instances/fabric-1.21.4"
        )
    )

    private fun defaultControlLayout(): TouchControlLayout = TouchControlLayout(
        id = "mj-claw-default",
        name = "MJ 4-Finger Claw",
        buttons = listOf(
            TouchControlButton("w", "W", "KEY_W", 14f, 58f, 56, 56, 0.72f),
            TouchControlButton("a", "A", "KEY_A", 7f, 72f, 56, 56, 0.72f),
            TouchControlButton("s", "S", "KEY_S", 14f, 72f, 56, 56, 0.72f),
            TouchControlButton("d", "D", "KEY_D", 21f, 72f, 56, 56, 0.72f),
            TouchControlButton("jump", "JUMP", "KEY_SPACE", 86f, 73f, 68, 68, 0.78f, ControlShape.CIRCLE),
            TouchControlButton("atk", "ATK", "MOUSE_LEFT", 86f, 48f, 62, 62, 0.78f, ControlShape.CIRCLE),
            TouchControlButton("use", "USE", "MOUSE_RIGHT", 74f, 60f, 58, 58, 0.75f, ControlShape.CIRCLE)
        )
    )
}
