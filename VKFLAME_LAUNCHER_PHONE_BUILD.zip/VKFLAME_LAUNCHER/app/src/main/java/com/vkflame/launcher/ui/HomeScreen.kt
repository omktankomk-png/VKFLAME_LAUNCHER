package com.vkflame.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vkflame.launcher.model.*
import com.vkflame.launcher.runtime.LaunchChecklist
import com.vkflame.launcher.ui.theme.*

@Composable
fun HomeScreen(
    activeProfile: GameProfile,
    profiles: List<GameProfile>,
    onSelectEdition: (MinecraftEdition) -> Unit,
    onSelectProfile: (GameProfile) -> Unit,
    onSelectLoader: (ModLoader) -> Unit,
    onRequestLaunch: () -> LaunchChecklist
) {
    var checklist by remember { mutableStateOf<LaunchChecklist?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Edition Switcher & Profile Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(VkSurface)
                    .border(1.dp, VkBorder, RoundedCornerShape(10.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                MinecraftEdition.entries.forEach { edition ->
                    val selected = activeProfile.edition == edition
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (selected) VkBluePrimary else Color.Transparent)
                            .clickable { onSelectEdition(edition) }
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = if (edition == MinecraftEdition.JAVA) "Java Edition" else "Bedrock Edition",
                            color = if (selected) Color.White else VkTextMuted,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            Text(
                text = "Profile: ${activeProfile.name}",
                color = VkTextMuted,
                fontSize = 13.sp
            )
        }

        // Central Launch Card (Foxy Craft Launcher inspired)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(VkSurface)
                .border(1.dp, VkBorder, RoundedCornerShape(16.dp))
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Minecraft ${activeProfile.mcVersion}",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = VkTextPrimary
            )
            Text(
                text = "${activeProfile.loader.name} · ${activeProfile.ramMb} MB RAM · ${activeProfile.resolution.width}x${activeProfile.resolution.height} (${activeProfile.renderer.name})",
                fontSize = 13.sp,
                color = VkTextMuted
            )

            if (activeProfile.edition == MinecraftEdition.JAVA) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ModLoader.entries.forEach { loader ->
                        val active = activeProfile.loader == loader
                        FilterChip(
                            selected = active,
                            onClick = { onSelectLoader(loader) },
                            label = { Text(loader.name) }
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${profiles.size} configured profiles",
                    color = VkTextMuted,
                    fontSize = 12.sp
                )
                Button(
                    onClick = { checklist = onRequestLaunch() },
                    colors = ButtonDefaults.buttonColors(containerColor = VkBluePrimary),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 28.dp, vertical = 14.dp)
                ) {
                    Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("PLAY", fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    checklist?.let { result ->
        AlertDialog(
            onDismissRequest = { checklist = null },
            containerColor = VkSurface,
            title = { Text("VKFLAME Native Launch Readiness", color = VkTextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(result.summary, color = VkTextMuted, fontSize = 13.sp)
                    result.missingNativeModules.forEach { item ->
                        Text("• $item", color = Color(0xFFFBBF24), fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { checklist = null }) {
                    Text("Close", color = VkBlueBright)
                }
            }
        )
    }
}
